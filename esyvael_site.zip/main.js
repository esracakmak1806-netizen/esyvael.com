
document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());
['year2','year3','year4','year5'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent=new Date().getFullYear(); });

async function fetchJSON(path){ try{ const r=await fetch(path); if(!r.ok) throw new Error('Not found'); return await r.json(); }catch(e){ console.warn('fetch failed',path); return []; } }

function slugify(s){ return s.toString().toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-çğıöşü]/g,''); }

// Render featured on index
(async function(){
  const books = await fetchJSON('books.json');
  const fg = document.getElementById('featuredGrid');
  if(fg && books.length){
    books.slice(0,3).forEach(b=>{
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<a href="book.html?book=${b.slug}"><img src="${b.cover}" alt="${b.title}"><h4>${b.title}</h4><p>${b.genre}</p></a>`;
      fg.appendChild(card);
    });
  }
})();

// Books page
(async function(){
  const books = await fetchJSON('books.json');
  const grid = document.getElementById('booksGrid');
  if(grid && books.length){
    books.forEach(b=>{
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<a href="book.html?book=${b.slug}"><img src="${b.cover}" alt="${b.title}"><h4>${b.title}</h4><p>${b.description.substring(0,120)}...</p></a>`;
      grid.appendChild(card);
    });
  }
})();

// Blog page
(async function(){
  const posts = await fetchJSON('posts.json');
  const grid = document.getElementById('postsGrid');
  if(grid && posts.length){
    posts.forEach(p=>{
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<h4>${p.title}</h4><p style="font-size:0.9rem;color:var(--muted)">${p.date}</p><p>${p.excerpt}</p><a href="post.html?post=${p.id}">Devamını oku</a>`;
      grid.appendChild(card);
    });
  }
})();

// Book detail page
(async function(){
  const params = new URLSearchParams(location.search);
  const slug = params.get('book');
  if(!slug) return;
  const books = await fetchJSON('books.json');
  const book = books.find(b => b.slug === slug);
  const area = document.getElementById('bookArea');
  if(!book || !area) return;
  area.innerHTML = `
    <div class="book-meta">
      <img src="${book.cover}" alt="${book.title}">
      <div class="meta"><strong>${book.title}</strong><div>${book.genre} • ${book.published}</div><div id="viewsCount">Okuma: 0</div></div>
    </div>
    <div class="book-content">
      <h2>${book.title}</h2>
      <p>${book.description}</p>
      <p><a class="btn" href="${book.pdf}" target="_blank">PDF olarak aç</a></p>
      <div id="disqus_thread"></div>
    </div>
  `;

  // CountAPI usage to increment and fetch views
  try{
    const namespace = 'esyvael'; // you can change if you create your own countapi namespace
    const key = slug;
    const res = await fetch('https://api.countapi.xyz/hit/' + namespace + '/' + key);
    const data = await res.json();
    const el = document.getElementById('viewsCount');
    if(el) el.textContent = 'Okuma: ' + (data.value||0);
  }catch(e){ console.warn('countapi failed',e); }

  // Disqus embed - replace 'esyvael' shortname after you create an account
  var d = document, s = d.createElement('script');
  s.src = 'https://esyvael.disqus.com/embed.js';
  s.setAttribute('data-timestamp', +new Date());
  (d.head || d.body).appendChild(s);
})();

// post detail simple page (post.html)
(async function(){
  const params = new URLSearchParams(location.search);
  const postId = params.get('post');
  if(!postId) return;
  const posts = await fetchJSON('posts.json');
  const post = posts.find(p => p.id === postId);
  if(!post) return;
  // if this is post.html element doesn't exist on other pages - create a simple page
  if(document.querySelector('.posts-grid')) return;
  document.title = post.title + ' — By Esyvael';
  const main = document.querySelector('main.container');
  if(main){
    main.innerHTML = `<article class="post"><h2>${post.title}</h2><p style="color:var(--muted)">${post.date}</p><div>${post.content}</div><div id="disqus_thread"></div></article>`;
    var d = document, s = d.createElement('script');
    s.src = 'https://esyvael.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
  }
})();
