
By Esyvael — Hazır Site Paketi
===============================

Bu paket, **esyvael.com** için hazırlanmış statik site şablonudur. İçinde örnek kitap kapakları, books.json ve posts.json bulunur.
Sen kitaplarını PDF ve kapak görselleri olarak siteye ekleyebilir; yorumlar Disqus üzerinden, okuma sayaçları CountAPI üzerinden çalışır.

Dosyalar:
- index.html — Ana sayfa
- books.html — Kitap listesi
- book.html — Kitap detay (örn: book.html?book=kirik-sokaklar)
- blog.html — Yazılar listesi
- post.html — Yazı detay sayfas
- about.html — Hakkımda
- books.json — Kitap listesi (metadata)
- posts.json — Blog yazıları (metadata)
- styles.css — Stil dosyası
- main.js — JavaScript (veri yükleme, CountAPI, Disqus embed)
- assets/ — örnek kapak görselleri
- books/ — (boş) buraya PDF dosyalarını ekleyeceksiniz

Hızlı Başlangıç (GitHub Pages + özel domain: esyvael.com)
---------------------------------------------------------

1) GitHub hesabı açın: https://github.com
2) Yeni bir repository oluşturun. Örneğin: esyvael-site (Public)
3) Oluşturduğunuz repo'ya bu klasördeki tüm dosyaları yükleyin.
   - Git kullanıyorsanız: `git init`, `git add .`, `git commit -m "initial"`, `git remote add origin <repo-url>`, `git push -u origin main`
   - GitHub web üzerinden de "Add file" -> "Upload files" ile yükleyebilirsiniz.
4) GitHub repo ayarlarından: Settings -> Pages (veya "Pages" sekmesi) -> Branch: main (root) seçin ve kaydedin.
   - Birkaç dakika içinde siteniz `https://<kullanıcıadı>.github.io/<repo>` şeklinde yayınlanır.
5) **Özel domain eklemek için (esyvael.com):**
   - Bir alan adı (domain) satın alın (Namecheap, Porkbun, Google Domains vb.).
   - GitHub Pages'da "Custom domain" kısmına `esyvael.com` yazın.
   - Domain sağlayıcınızda DNS ayarlarına şu kayıtları ekleyin (Namecheap örneği):
     - A kayıtları (4 adet) — GitHub Pages IP'leri: 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
     - CNAME kaydı: `www` -> `<kullanıcıadı>.github.io`  (veya doğrudan `esyvael.com`'u yönlendirin)
   - DNS değişikliklerinin yayılması genelde birkaç dakika ila 24 saat alabilir.

Kitap Ekleme (GitHub Web UI ile kolay yol)
-----------------------------------------
1) Repo içinde `books/` klasörü oluşturun (eğer yoksa).
2) Her kitap için PDF dosyanızı `books/` içerisine yükleyin (ör: books/mybook.pdf).
3) Kapak görselini `assets/` klasörüne yükleyin (ör: assets/mycover.jpg).
4) `books.json` dosyasını düzenleyerek yeni kitap objesini ekleyin:
   {
     "slug": "benim-kitap",
     "title": "Benim Kitabım",
     "cover": "assets/mycover.jpg",
     "description": "Kitap açıklaması...",
     "pdf": "books/benim-kitap.pdf",
     "genre": "Dram",
     "published": "2025-10-20"
   }
5) Commit ve push yapın. Site otomatik güncellenecektir.

Disqus (Yorumlar) Kurulumu
--------------------------
1) https://disqus.com/ adresine gidin ve ücretsiz bir hesap oluşturun.
2) "Add Disqus to your site" -> Site name: `esyvael` (veya tercih ettiğiniz kısa ad)
3) Disqus size bir `shortname` verecek (ör: esyvael). Bunu aldıktan sonra `main.js` içinde geçen `s.src = 'https://esyvael.disqus.com/embed.js';` satırını kısa adınıza uygun şekilde bırakın.
4) Kullanıcılar artık kitap sayfalarında yorum yapabilecektir.

Okuma Sayaçı - CountAPI
-----------------------
- Sayaç için CountAPI kullanılmıştır. Örneğin bir kitap sayfası açıldığında JS şu endpoint'e istek yapar:
  `https://api.countapi.xyz/hit/esyvael/benim-kitap`
- Bu endpoint otomatik olarak bir anahtar oluşturur ve her çağrıda arttırır. Görüntülenme sayısını CountAPI'den alıp sayfada gösterir.
- Eğer kendi namespace'inizi tercih ederseniz CountAPI'de kayıt oluşturabilirsiniz, ama varsayılan kullanım için ekstra bir anahtar gerekmiyor.

Ek Notlar ve İpuçları
---------------------
- Eğer PDF'leri doğrudan GitHub'a yüklerseniz, dosyaların doğrudan linkleri çalışır ve "PDF olarak aç" butonu kullanıcıya PDF'i tarayıcıda gösterir.
- Eğer ileride daha profesyonel bir yönetim paneli isterseniz, Netlify CMS veya Forestry gibi çözümler ekleyebiliriz.
- İstersen ben bu repo'yu doğrudan GitHub'a **site hazır** şekilde yükleyip sana link verebilirim — fakat bunun için GitHub erişimine ihtiyacın var.
